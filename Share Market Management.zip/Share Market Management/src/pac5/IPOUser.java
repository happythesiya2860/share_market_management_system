package pac5;
import pac6.ShareMarketManagementSystem;
import java.sql.*;
import java.util.Scanner;

public class IPOUser extends ShareMarketManagementSystem{
    public static void call() throws Exception {
        Scanner sc = new Scanner(System.in);
        String dburl = "jdbc:mysql://localhost:3306/share-market";
        String dbuser = "root";
        String dbpass = "";
        String drivername = "com.mysql.cj.jdbc.Driver";
        Class.forName(drivername);
        Connection con = DriverManager.getConnection(dburl, dbuser, dbpass);

        if (con != null) {
            System.out.println("Database connection successful.");
        }

        // Create IPOAPPLY table if not exists
        Statement st = con.createStatement();
        String createTable = "CREATE TABLE IF NOT EXISTS IPOAPPLY (IPO_NAME VARCHAR(50), CLIENT_PAN VARCHAR(50), LOT INT, UPI_ID VARCHAR(50))";
        st.executeUpdate(createTable);

        // Display IPOs
        String fetchIPOs = "SELECT * FROM IPO";
        ResultSet rs1 = st.executeQuery(fetchIPOs);
        System.out.println("\n--- Available IPOs ---");
        while (rs1.next()) {
            System.out.println("IPO: " + rs1.getString(1) + " (" + rs1.getString(9) + ")");
            System.out.println("Bid: " + rs1.getDouble(2));
            System.out.println("Lot: " + rs1.getInt(3));
            System.out.println("Start: " + rs1.getString(4));
            System.out.println("Last: " + rs1.getString(5));
            System.out.println("Allotment: " + rs1.getString(6));
            System.out.println("Size (cr): " + rs1.getDouble(7));
            System.out.println("1 Lot Price: " + rs1.getDouble(8));
            System.out.println("------------------------------------------");
        }

        System.out.println("\nDo you want to apply for an IPO? (yes/no)");
        String ans = sc.nextLine();

        // Hardcoded PAN value
        String pan = client_pan;

        if (ans.equalsIgnoreCase("yes")) {
            System.out.print("Enter the IPO name: ");
            String search_ipo_name = sc.nextLine();

            // Check if IPO exists
            String st1 = "SELECT * FROM IPO WHERE IPO_NAME = ?";
            PreparedStatement ps1 = con.prepareStatement(st1);
            ps1.setString(1, search_ipo_name);
            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {
                // Check if already applied
                String st2 = "SELECT * FROM IPOAPPLY WHERE IPO_NAME = ? AND CLIENT_PAN = ?";
                PreparedStatement ps2 = con.prepareStatement(st2);
                ps2.setString(1, search_ipo_name);
                ps2.setString(2, pan);
                ResultSet rs2 = ps2.executeQuery();

                if (rs2.next()) {
                    System.out.println("You already applied for this IPO.");
                    System.out.println("Choose an option:\n1. Update lot\n2. Cancel application \n3.default exit");
                    int choice = sc.nextInt();
                    sc.nextLine(); // consume leftover newline

                    switch (choice) {
                        case 1:
                            System.out.print("Enter new lot size: ");
                            int newLot = sc.nextInt();
                            sc.nextLine();
                            String updateQuery = "UPDATE IPOAPPLY SET LOT = ? WHERE IPO_NAME = ? AND CLIENT_PAN = ?";
                            PreparedStatement ps3 = con.prepareStatement(updateQuery);
                            ps3.setInt(1, newLot);
                            ps3.setString(2, search_ipo_name);
                            ps3.setString(3, pan);
                            ps3.executeUpdate();
                            System.out.println("Lot updated successfully.");
                            break;

                        case 2:
                            String deleteQuery = "DELETE FROM IPOAPPLY WHERE IPO_NAME = ? AND CLIENT_PAN = ?";
                            PreparedStatement ps4 = con.prepareStatement(deleteQuery);
                            ps4.setString(1, search_ipo_name);
                            ps4.setString(2, pan);
                            ps4.executeUpdate();
                            System.out.println("Application cancelled successfully.");
                            break;

                        default:
                            System.out.println("Invalid choice.");
                            break;
                    }

                } else {
                    // New application
                    System.out.print("Enter the lot: ");
                    int lot = sc.nextInt();
                    sc.nextLine(); // consume newline
                    System.out.print("Enter your UPI ID: ");
                    String upi_id = sc.nextLine();

                    String insertQuery = "INSERT INTO IPOAPPLY VALUES (?, ?, ?, ?)";
                    PreparedStatement ps5 = con.prepareStatement(insertQuery);
                    ps5.setString(1, search_ipo_name);
                    ps5.setString(2, pan);
                    ps5.setInt(3, lot);
                    ps5.setString(4, upi_id);
                    ps5.executeUpdate();
                    System.out.println("IPO application submitted successfully.");
                }

            } else {
                System.out.println("IPO not found.");
            }
        }

    }
}
