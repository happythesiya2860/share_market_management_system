package pac8;
import pac6.*;
import  java.sql.*;
import java.util.Scanner;
import java.math.*;
public class searchAndWatchlist extends ShareMarketManagementSystem{
    static String watchListName;
    static String stockName;
    static String clientMobileNumber = client_mobile_number;  // Hardcoded
    static String fetchedStockName;
    static double fetchedStockPrice;
    static String addStockWatchlistName;
    static String removeStockWatchlistName;
    static String printwatchlistName ;
    public static void call() throws Exception{
        Scanner sc = new Scanner(System.in);
        // Load JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Connect to database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/share-market", "root", "");

        Statement st = con.createStatement();
        boolean b = true;
        while (b){
            System.out.println("Enter your choice \n1.Create watchlist \n2.Add stock to watchlist \n3.Remove stock from" +
                    "watchlist \n4.view watchlist \n5.Exit");
            int watchlist_choice = sc.nextInt();
            switch (watchlist_choice){
                case 1 : do {
                    System.out.print("Enter the watch list name: ");
                    sc.nextLine();
                    watchListName = sc.nextLine();

                    if (validationWatchlistName(watchListName)) {
                        String createTableQuery = "CREATE TABLE IF NOT EXISTS " + watchListName + " (" +
                                "STOCK_NAME VARCHAR(50), " +
                                "STOCK_PRICE DOUBLE, " +
                                "CLIENT_NUMBER VARCHAR(50), " +
                                "WATCH_LIST VARCHAR(50))";
                        st.executeUpdate(createTableQuery);
                        break;
                    } else {
                        System.out.println("Invalid watch list name. Use only letters and digits.");
                    }
                } while (!validationWatchlistName(watchListName));
                    break;
                case 2 :
                    // Search Stock in STOCK_DATA
                    System.out.print("Enter the stock name: ");
                    sc.nextLine();
                    stockName = sc.nextLine();

                    String selectStock = "SELECT * FROM STOCK_DATA WHERE STOCK_NAME = ?";
                    PreparedStatement ps1 = con.prepareStatement(selectStock);
                    ps1.setString(1, stockName);
                    ResultSet rs = ps1.executeQuery();

                    if (rs.next()) {
                        fetchedStockName = rs.getString("STOCK_NAME");
                        fetchedStockPrice = rs.getDouble("STOCK_PRICE");
                        fetchedStockPrice  = fetchedStockPrice  + fetchedStockPrice  * (((Math.random() * (5 - (-5))) + (-5)) / 100);

                        System.out.println("Stock: " + fetchedStockName);
                        System.out.println("Price: " + fetchedStockPrice);
                    } else {
                        System.out.println("Stock not found.");
                        return;
                    }

                    //  Add Stock to Watchlist
                    System.out.print("Do you want to add stock to watch list? (yes or no): ");
                    String answer = sc.nextLine();

                    if (answer.equalsIgnoreCase("yes")) {
                        do {
                            System.out.print("Enter the watch list name: ");
                            addStockWatchlistName = sc.nextLine();

                            try {
                                String testQuery = "SELECT 1 FROM " + addStockWatchlistName + " LIMIT 1";
                                Statement testStmt = con.createStatement();
                                testStmt.executeQuery(testQuery); // if table doesn't exist, this will throw
                            } catch (SQLException e) {
                                System.out.println("Watchlist does not exist. Please create it first.");
                                break; // skip adding stock
                            }


                            if (validationWatchlistName(addStockWatchlistName)) {
                                String insertQuery = "INSERT INTO " + addStockWatchlistName + " (STOCK_NAME, STOCK_PRICE, CLIENT_NUMBER, WATCH_LIST) VALUES (?, ?, ?, ?)";
                                PreparedStatement ps2 = con.prepareStatement(insertQuery);
                                ps2.setString(1, fetchedStockName);
                                ps2.setDouble(2, fetchedStockPrice);
                                ps2.setString(3, clientMobileNumber);
                                ps2.setString(4, addStockWatchlistName);
                                ps2.executeUpdate();

                                System.out.println("Stock added to watch list.");
                            } else {
                                System.out.println("Invalid watch list name. Try again.");
                            }
                        } while (!validationWatchlistName(addStockWatchlistName));
                    }
                    break;
                case 3 :
                    System.out.print("Enter the stock name: ");
                    sc.nextLine();
                    stockName = sc.nextLine();

                    String selectStockForRemove = "SELECT * FROM STOCK_DATA WHERE STOCK_NAME = ?";
                    PreparedStatement ps2 = con.prepareStatement(selectStockForRemove);
                    ps2.setString(1, stockName);
                    ResultSet rs1 = ps2.executeQuery();

                    if (rs1.next()) {
                        fetchedStockName = rs1.getString("STOCK_NAME");
                        fetchedStockPrice = rs1.getDouble("STOCK_PRICE");
                        fetchedStockPrice  = fetchedStockPrice  + fetchedStockPrice  * (((Math.random() * (5 - (-5))) + (-5)) / 100);

                        System.out.println("Stock: " + fetchedStockName);
                        System.out.println("Price: " + fetchedStockPrice);
                    } else {
                        System.out.println("Stock not found.");
                        return;
                    }
                    System.out.print("Do you want to remove stock from watch list? (yes or no): ");
                    String answerForRemove = sc.nextLine();
                    if (answerForRemove.equalsIgnoreCase("yes")){

                        do {
                            System.out.print("Enter the watch list name: ");
                            removeStockWatchlistName= sc.nextLine();

                            if (validationWatchlistName(removeStockWatchlistName)) {

                                String removeStockName = stockName;

                                String findStockForRemove = "SELECT * FROM " + removeStockWatchlistName +
                                        " WHERE STOCK_NAME = ? AND WATCH_LIST = ? AND CLIENT_NUMBER = ?";
                                PreparedStatement ps3 = con.prepareStatement(findStockForRemove);
                                ps3.setString(1, removeStockName);
                                ps3.setString(2, removeStockWatchlistName);
                                ps3.setString(3, clientMobileNumber);
                                ResultSet rs3 = ps3.executeQuery();
                                String searchStock = "";
                                if(rs3.next()){
                                    searchStock = rs3.getString(1);
                                }
                                if(removeStockName.equalsIgnoreCase(searchStock)){
                                    String removeStockQuery = "DELETE FROM " + removeStockWatchlistName +
                                            " WHERE STOCK_NAME = ? AND WATCH_LIST = ? AND CLIENT_NUMBER = ?";
                                    PreparedStatement ps4 = con.prepareStatement(removeStockQuery);
                                    ps4.setString(1, removeStockName);
                                    ps4.setString(2, removeStockWatchlistName);
                                    ps4.setString(3, clientMobileNumber);
                                    ps4.executeUpdate();

                                    ps4.executeUpdate();
                                }
                                else {
                                    System.out.println("Stock not found in watchlist");
                                }
                            } else {
                                System.out.println("Invalid watch list name. Try again.");
                            }
                        } while (!validationWatchlistName(removeStockWatchlistName));
                    }
                    break;
                case 4 :

                    do {
                        System.out.print("Enter the watch list name: ");
                        sc.nextLine();
                        printwatchlistName = sc.nextLine();

                        if (validationWatchlistName(printwatchlistName)) {
                            String printwatchListQuery = "SELECT * FROM " + printwatchlistName +
                                    " WHERE CLIENT_NUMBER = ? AND WATCH_LIST = ?";
                            PreparedStatement ps5 = con.prepareStatement(printwatchListQuery);
                            ps5.setString(1, clientMobileNumber);
                            ps5.setString(2, printwatchlistName);

                            ResultSet rs3 = ps5.executeQuery();
                            if(rs3.next()){
                                System.out.println(rs3.getString(1)+"---"+rs3.getDouble(2));
                            }
                            else {
                                System.out.println("Watchlist not found or empty");
                            }
                        } else {
                            System.out.println("Invalid watch list name. Try again.");
                        }
                    }while (!validationWatchlistName(printwatchlistName));
                    break;
                case 5 :
                    b = false;
                    break;
                default:
                    break;
            }
        }
        updateStockData(fetchedStockPrice,fetchedStockName);
    }
    static public void updateStockData(double newPrice ,String StockName) throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Connect to database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/share-market", "root", "");

        String st1 = "UPDATE STOCK_DATA SET STOCK_PRICE = ? WHERE STOCK_NAME = ?";
        PreparedStatement ps1 = con.prepareStatement(st1);
        ps1.setDouble(1,newPrice);
        ps1.setString(2,StockName);
        ps1.executeUpdate();
    }
    static public boolean validationWatchlistName(String wname) {
        for (char c : wname.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) {
                return false;
            }
        }
        return true;
    }
}