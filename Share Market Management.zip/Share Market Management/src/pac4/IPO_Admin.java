package pac4;
import java.sql.*;
import java.util.Scanner;

class IpoAdmin {
    static String ipo_name;
    static double bid_price;
    static int lot_size;
    static String start_date;
    static String last_date;
    static String allotment_date;
    static double ipo_size;
    static double one_lot_amount;
    static String ipo_type;
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        String dburl = "jdbc:mysql://localhost:3306/share-market";
        String dbuser = "root";
        String dbpass = "";
        String drivername = "com.mysql.cj.jdbc.Driver";
        Class.forName(drivername);
        Connection con = DriverManager.getConnection(dburl, dbuser, dbpass);

        Statement st = con.createStatement();
        if (con != null) {
            System.out.println("Successful");
        }
        boolean b = true;
        while (b){
            System.out.println("Enter your choice \n1.Add IPO \n2.Remove IPO \n3.Print IPO \n4. Exit");
            int ipo_choice = sc.nextInt();
            switch (ipo_choice) {
                case 1:
                    System.out.println("Enter the ipo name : ");
                    sc.nextLine();
                    ipo_name = sc.nextLine();
                    String st7 = "SELECT * FROM IPO WHERE IPO_NAME = ?";
                    PreparedStatement ps4 = con.prepareStatement(st7);
                    ps4.setString(1,ipo_name);
                    ResultSet rs5 = ps4.executeQuery();
                    if(rs5.next()){
                        if(rs5.getString(1).equalsIgnoreCase(ipo_name)){
                            System.out.println("IPO already exists");
                        }
                    }
                    else {
                        System.out.println("Enter the bid price :");
                        bid_price = sc.nextDouble();
                        System.out.println("Enter the lot one size : ");
                        lot_size = sc.nextInt();
                        System.out.println("Enter the start date : ");
                        sc.nextLine();
                        start_date = sc.nextLine();
                        System.out.println("Enter the last date : ");
                        last_date = sc.nextLine();
                        System.out.println("Enter the allotment date : ");
                        allotment_date = sc.nextLine();
                        System.out.println("Enter the ipo Size (in cr)");
                        ipo_size = sc.nextDouble();
                        one_lot_amount = bid_price * lot_size;
                        System.out.println("Enter the IPO type (Mainboard/SME)");
                        sc.nextLine();
                        ipo_type = sc.nextLine();


                        String st1 = "CREATE TABLE IF NOT EXISTS IPO (IPO_NAME VARCHAR(50), BID_PRICE DOUBLE , LOT_SIZE INT ," +
                                "START_DATE VARCHAR(50), LAST_DATE VARCHAR(50), ALLOTMENT_DATE VARCHAR(50), IPO_SIZE DOUBLE, " +
                                "ONE_LOT_AMOUNT DOUBLE, IPO_TYPE VARCHAR(50))";
                        st.executeUpdate(st1);

                        String st2 = "INSERT INTO IPO VALUES(?,?,?,?,?,?,?,?,?)";
                        PreparedStatement ps1 = con.prepareStatement(st2);
                        ps1.setString(1, ipo_name);
                        ps1.setDouble(2, bid_price);
                        ps1.setInt(3, lot_size);
                        ps1.setString(4, start_date);
                        ps1.setString(5, last_date);
                        ps1.setString(6, allotment_date);
                        ps1.setDouble(7, ipo_size);
                        ps1.setDouble(8, one_lot_amount);
                        ps1.setString(9, ipo_type);
                        ps1.executeUpdate();
                    }
                    break;
                case 2:
                    System.out.println("Enter the IPO name ");
                    sc.nextLine();
                    String remove_ipo_name = sc.nextLine().trim();

                    String st3 = "SELECT * FROM IPO WHERE UPPER(IPO_NAME) = UPPER(?)";
                    PreparedStatement ps2 = con.prepareStatement(st3);
                    ps2.setString(1, remove_ipo_name);
                    ResultSet rs = ps2.executeQuery();
                    if(rs.next()){
                        if (rs.getString(1).equalsIgnoreCase(remove_ipo_name)) {
                            String st4 = "DELETE FROM IPO WHERE UPPER(IPO_NAME) = UPPER(?)";
                            PreparedStatement ps3 = con.prepareStatement(st4);
                            ps3.setString(1, remove_ipo_name);
                            ps3.executeUpdate();
                        }
                    }
                    else {
                        System.out.println("IPO not available");
                    }
                    break;
                case 3:
                    String st4 = "SELECT * FROM IPO ";
                    ResultSet rs1 = st.executeQuery(st4);
                    while (rs1.next()) {
                        System.out.println("IPO : " + rs1.getString(1) + "(" + rs1.getString(9) + ")");
                        System.out.println("Bid : " + rs1.getDouble(2));
                        System.out.println("Lot : " + rs1.getInt(3));
                        System.out.println("Start : " + rs1.getString(4));
                        System.out.println("Last : " + rs1.getString(5));
                        System.out.println("Allotment : " + rs1.getString(6));
                        System.out.println("Size(cr) : " + rs1.getDouble(7));
                        System.out.println("1 lot : " + rs1.getDouble(8));
                        System.out.println("------------------------------------------");
                    }
                    break;
                case 4:
                    b = false;
                    break;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
    }
}