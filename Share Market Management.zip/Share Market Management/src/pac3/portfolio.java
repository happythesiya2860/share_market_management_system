package pac3;
import pac6.ShareMarketManagementSystem;
import java.sql.*;
import java.util.Scanner;

public class portfolio extends ShareMarketManagementSystem{
    static double total_invest_ment;
    static double current_value;
    static double current_price;
    static double current_qty;
    static double total_invest;
    static double overall_current_value;
    static double diffrence;
    public static void call() throws Exception {
        Scanner sc = new Scanner(System.in);
        String dburl = "jdbc:mysql://localhost:3306/share-market";
        String dbuser = "root";
        String dbpass = "";
        String drivername = "com.mysql.cj.jdbc.Driver";
        Class.forName(drivername);
        Connection con = DriverManager.getConnection(dburl, dbuser, dbpass);
        Statement st2 = con.createStatement();
        String st = "SELECT * FROM PORTFOLIO WHERE CLIENT_MOBILE_NUMBER = ?";
        PreparedStatement ps1 = con.prepareStatement(st);
        ps1.setString(1,client_mobile_number);
        ResultSet rs = ps1.executeQuery();
        while (rs.next()){
            System.out.println("NAME : "+rs.getString(1));
            System.out.println("avg : "+rs.getDouble(2));
            current_price = rs.getDouble(2);
            current_price = current_price + current_price * (((Math.random() * (5 - (-5))) + (-5)) / 100);
            System.out.println("Qty. :"+rs.getInt(3));
            current_qty = rs.getInt(3);
            current_value = current_price*current_qty;
            total_invest = rs.getDouble(4);
            overall_current_value = rs.getDouble(7);
            overall_current_value = overall_current_value+(current_value-total_invest);
            String update = "UPDATE PORTFOLIO SET CURRENT_VALUE = ?, TOTAL_VALUE = ? WHERE CLIENT_MOBILE_NUMBER = ?";
            PreparedStatement ps2 = con.prepareStatement(update);
            ps2.setDouble(1,current_value);
            ps2.setDouble(2,overall_current_value);
            ps2.setString(3,client_mobile_number);
            ps2.executeUpdate();


            System.out.println("Invest : "+rs.getDouble(4));
            System.out.println("Now value : "+rs.getDouble(5));
            System.out.println("---------------------------------------");
            System.out.println();

            // update in stock data
            updateStockData(current_price,rs.getString(1));
        }
        String find = "SELECT * FROM PORTFOLIO WHERE CLIENT_MOBILE_NUMBER = ?";
        PreparedStatement ps3 = con.prepareStatement(find);
        ps3.setString(1,client_mobile_number);
        ResultSet rs1 = ps3.executeQuery();
        while (rs1.next()){
            total_invest_ment = rs1.getDouble(6);
            overall_current_value = rs1.getDouble(7);
        }
        System.out.println("Total Investment : "+total_invest_ment);
        System.out.println("Total Value Now : "+overall_current_value);
    }
    static public void updateStockData(double newPrice ,String StockName) throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Connect to database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/share-market", "root", "");

        String st1 = "UPDATE STOCK_DATA SET STOCK_PRICE = ? WHERE STOCK_NAME = ?";
        PreparedStatement ps1 = con.prepareStatement(st1);
        ps1.setDouble(1,newPrice);
        ps1.setString(2,StockName);
        ps1.executeUpdate();
    }
}