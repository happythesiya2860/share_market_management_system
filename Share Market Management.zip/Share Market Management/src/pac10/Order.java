package pac10;
public class Order {
    static String[] orders;
   static int size;
   static int top;

    public Order(){
        size = 100;
        top = -1;
        orders = new String[size];
    }
    public static void pushorder(String order){
        if(top>=size-1){
            System.out.println("Order Overflow");
        }
        else {
            top++;
            orders[top] = order;
        }
    }
    public static void poporder(){
        if(top==-1){
            System.out.println("Data not avilable");
        }
        else {
            System.out.println(orders[top]+" is remove");
            top--;
        }
    }
    public static void display(){
        for(int i = top ; i>=0 ; i--){
            System.out.println(orders[i]);
        }
    }
}