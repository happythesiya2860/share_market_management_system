package pac6;
import pac1.*;
import pac8.searchAndWatchlist;
import pac7.NewUserRegistration;
import pac9.fund;
import pac10.Order;
import pac11.trancationhistory;
import pac2.SELL;
import pac3.portfolio;
import pac5.IPOUser;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
import java.sql.*;
public class ShareMarketManagementSystem  {
    static public String client_mobile_number;
    static public int security_pin;
    static public String client_pan;
    static public Order obj = new Order();
    public static void main(String[] args)throws Exception {
        Scanner sc = new Scanner(System.in);
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Connect to the MySQL database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/share-market", "root", "");
        Statement st = con.createStatement();
        boolean b = true;
        do {

            System.out.println("Enter the choice : \n1.New registration \n2.Login \n3.exit");
            int choice2 = sc.nextInt();
            sc.nextLine();
            switch (choice2){
                case 1 : NewUserRegistration.call();
                    break;
                case 2 :
                    //get client mobile number
                    do {
                        System.out.println("Enter Mobile Number");
                        client_mobile_number = sc.nextLine();
                    }while (!isValidMobileNumber(client_mobile_number));

                    String find_pan = "SELECT * FROM CLIENT_DATA WHERE CLIENT_MOBILE_NUMBER = ?";
                    PreparedStatement ps2 = con.prepareCall(find_pan);
                    ps2.setString(1,client_mobile_number);
                    ResultSet rs2 = ps2.executeQuery();
                    while (rs2.next()){
                        client_pan = rs2.getString(2);
                    }

                    //get pin and check is valid or not
                    boolean isvalidpin = true;
                    boolean valid_for_login = false;
                    do {
                        System.out.println("Enter your pin(4 digit)");
                        security_pin = sc.nextInt();
                        String check_pin = "SELECT * FROM PIN WHERE CLIENT_MOBILE_NUMBER = ?";
                        PreparedStatement ps1 = con.prepareStatement(check_pin);
                        ps1.setString(1,client_mobile_number);
                        ResultSet rs1 = ps1.executeQuery();
                        while (rs1.next()){
                            if(rs1.getInt(2)==security_pin){
                                isvalidpin = false;
                                valid_for_login = true;
                            }
                            else {
                                System.out.println("Enter valid pin");
                            }
                        }
                    }while (isvalidpin);
                    if(valid_for_login){
                        while (b){
                            System.out.println("Enter your choice : \n1.watchlist \n2.Fund \n3.Buy Stocks \n4.sell stocks\n5.Portfolio \n6.IPO \n7.Today's Order History \n8.view traction history \n9.exit");
                            int choice = sc.nextInt();
                            switch (choice){
                                case 1 : searchAndWatchlist.call();
                                    break;
                                case 2 : fund.call();
                                    break;
                                case 3 : BUY.call();
                                    break;
                                case 4 : SELL.call();
                                    break;
                                case 5 : portfolio.call();
                                    break;
                                case 6 :IPOUser.call();
                                    break;
                                case 7 : Order.display();
                                    break;
                                case 8 : trancationhistory.display();
                                    break;
                                case 9 : b = false;
                                    break;
                                default:
                                    System.out.println("Invalid choice");
                                    break;
                            }
                        }
                    }
                    break;
                default:
                    System.out.println("Invalid choice");
                    break;
                case 3 : b = false;
                    break;
            }
        }while (b);
    }
    public static boolean isValidMobileNumber(String mobileNumber) {
        if (mobileNumber.length() != 10) return false;
        for (int i = 0; i < 10; i++) {
            if (!Character.isDigit(mobileNumber.charAt(i))) return false;
        }
        char firstChar = mobileNumber.charAt(0);
        return firstChar == '6' || firstChar == '7' || firstChar == '8' || firstChar == '9';
    }
}