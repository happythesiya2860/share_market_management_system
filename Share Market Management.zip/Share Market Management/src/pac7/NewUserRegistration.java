package pac7;
import java.sql.*;
import java.util.Scanner;

public class NewUserRegistration {

    // Static variables to store client details
    public static String clientMobileNumber;
    public static String clientName;
    public static String clientAadharNumber;
    public static String clientPanNumber;
    public static String clientAccountNumber;
    public static String clientIFSC;
    public static int security_pin;

    public static void call() throws Exception {
        Scanner sc = new Scanner(System.in);
        // Load JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Connect to the MySQL database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/share-market", "root", "");

        // Create CLIENT_DATA table with UNIQUE constraints
        Statement st = con.createStatement();
        String createTableQuery = "CREATE TABLE IF NOT EXISTS CLIENT_DATA (" +
                "CLIENT_NAME VARCHAR(50), " +
                "CLIENT_PAN VARCHAR(50) UNIQUE, " +
                "CLIENT_AADHAR VARCHAR(50) UNIQUE, " +
                "CLIENT_MOBILE_NUMBER VARCHAR(50) UNIQUE, " +
                "CLIENT_ACCOUNT_NUMBER VARCHAR(50), " +
                "CLIENT_IFSC VARCHAR(50))";
        st.executeUpdate(createTableQuery);

        // Create PIN table
        String createPinTable = "CREATE TABLE IF NOT EXISTS PIN (CLIENT_MOBILE_NUMBER VARCHAR(50), PIN INT)";
        st.executeUpdate(createPinTable);

        // Create trigger to log duplicate attempts
        createDuplicateCheckTrigger(con);

        // Input and validate mobile number
        do {
            System.out.print("Enter your mobile number (10 digits, starts with 6/7/8/9): ");
            clientMobileNumber = sc.nextLine();
            if (!isValidMobileNumber(clientMobileNumber)) {
                System.out.println("Invalid mobile number! Please enter a valid 10-digit number starting with 6, 7, 8, or 9.");
            }
        } while (!isValidMobileNumber(clientMobileNumber));

        // Get client name
        System.out.print("Enter your full name: ");
        clientName = sc.nextLine();

        // Input and validate Aadhar number
        do {
            System.out.print("Enter your 12-digit Aadhar number: ");
            clientAadharNumber = sc.nextLine();
            if (!isValidAadharNumber(clientAadharNumber)) {
                System.out.println("Invalid Aadhar number! Please enter a valid 12-digit number.");
            }
        } while (!isValidAadharNumber(clientAadharNumber));

        // Input and validate PAN number
        do {
            System.out.print("Enter your 10-character PAN number (e.g., ABCDE1234F): ");
            clientPanNumber = sc.nextLine();
            if (!isValidPanNumber(clientPanNumber)) {
                System.out.println("Invalid PAN number! Please enter a valid PAN (5 letters, 4 digits, 1 letter).");
            }
        } while (!isValidPanNumber(clientPanNumber));

        // Get bank account number
        System.out.print("Enter your bank account number: ");
        clientAccountNumber = sc.nextLine();

        // Get IFSC code
        System.out.print("Enter your bank IFSC code: ");
        clientIFSC = sc.nextLine();

        // Insert client data into CLIENT_DATA table
        String insertQuery = "INSERT INTO CLIENT_DATA (CLIENT_NAME, CLIENT_PAN, CLIENT_AADHAR, CLIENT_MOBILE_NUMBER, CLIENT_ACCOUNT_NUMBER, CLIENT_IFSC) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(insertQuery);
        ps.setString(1, clientName);
        ps.setString(2, clientPanNumber);
        ps.setString(3, clientAadharNumber);
        ps.setString(4, clientMobileNumber);
        ps.setString(5, clientAccountNumber);
        ps.setString(6, clientIFSC);
        try {
            ps.executeUpdate();
        } catch (SQLException e) {
            // Check for duplicate key error (SQLSTATE '23000')
            if (e.getSQLState().equals("23000")) {
                // Check which field caused the duplicate
                if (isDuplicate(con, "CLIENT_PAN", clientPanNumber)) {
                    System.out.println("Registration failed: Duplicate PAN number detected");
                } else if (isDuplicate(con, "CLIENT_AADHAR", clientAadharNumber)) {
                    System.out.println("Registration failed: Duplicate Aadhar number detected");
                } else if (isDuplicate(con, "CLIENT_MOBILE_NUMBER", clientMobileNumber)) {
                    System.out.println("Registration failed: Duplicate Mobile number detected");
                } else {
                    System.out.println("Registration failed: Duplicate entry detected");
                }
                return;
            } else {
                // Handle other database issues as messages
                System.out.println("Registration failed due to database issue: " + e.getMessage());
                return;
            }
        }

        // Set security pin
        boolean pinSet = false;
        do {
            try {
                setPin(sc, con);
                System.out.println("Pin set successfully");
                pinSet = true;
            } catch (SQLException e) {
                System.out.println("Failed to set pin due to database issue: " + e.getMessage());
            }
        } while (!pinSet);

        System.out.println("Client registered successfully!");
    }

    // Method to set security pin, using passed Scanner and Connection
    private static void setPin(Scanner sc, Connection con) throws SQLException {
        System.out.println("Enter the pin");
        security_pin = sc.nextInt();
        String insertPin = "INSERT INTO PIN VALUES (?,?)";
        PreparedStatement ps5 = con.prepareStatement(insertPin);
        ps5.setString(1, clientMobileNumber);
        ps5.setInt(2, security_pin);
        int r = ps5.executeUpdate();
        if (r <= 0) {
            System.out.println("Pin not set");
        }
    }

    // Method to create trigger for logging duplicate attempts
    private static void createDuplicateCheckTrigger(Connection con) throws SQLException {
        Statement st = con.createStatement();
        // Drop existing trigger if it exists to avoid conflicts
        st.executeUpdate("DROP TRIGGER IF EXISTS log_duplicate_attempts");

        // Create a table to log duplicate attempts (optional, for tracking)
        st.executeUpdate("CREATE TABLE IF NOT EXISTS DUPLICATE_LOG (" +
                "ATTEMPT_TIME TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "CLIENT_PAN VARCHAR(50), " +
                "CLIENT_AADHAR VARCHAR(50), " +
                "CLIENT_MOBILE_NUMBER VARCHAR(50))");

        // Create trigger to log duplicate attempts before insert
        String triggerQuery =
                        "CREATE TRIGGER log_duplicate_attempts " +
                        "BEFORE INSERT ON CLIENT_DATA " +
                        "FOR EACH ROW " +
                        "BEGIN " +
                        "    IF EXISTS (SELECT 1 FROM CLIENT_DATA WHERE CLIENT_PAN = NEW.CLIENT_PAN OR " +
                        "               CLIENT_AADHAR = NEW.CLIENT_AADHAR OR " +
                        "               CLIENT_MOBILE_NUMBER = NEW.CLIENT_MOBILE_NUMBER) THEN " +
                        "        INSERT INTO DUPLICATE_LOG (CLIENT_PAN, CLIENT_AADHAR, CLIENT_MOBILE_NUMBER) " +
                        "        VALUES (NEW.CLIENT_PAN, NEW.CLIENT_AADHAR, NEW.CLIENT_MOBILE_NUMBER); " +
                        "    END IF; " +
                        "END " ;
        st.executeUpdate(triggerQuery);
    }

    // Helper method to check if a value exists in a specific column
    private static boolean isDuplicate(Connection con, String column, String value) throws SQLException {
        String query = "SELECT 1 FROM CLIENT_DATA WHERE " + column + " = ?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, value);
        ResultSet rs = ps.executeQuery();
        boolean exists = rs.next();
        return exists;
    }

    // Validate Mobile Number
    public static boolean isValidMobileNumber(String mobileNumber) {
        if (mobileNumber == null || mobileNumber.length() != 10) return false;
        for (int i = 0; i < 10; i++) {
            if (!Character.isDigit(mobileNumber.charAt(i))) return false;
        }
        char firstChar = mobileNumber.charAt(0);
        return firstChar == '6' || firstChar == '7' || firstChar == '8' || firstChar == '9';
    }

    // Validate Aadhar Number
    public static boolean isValidAadharNumber(String aadharNumber) {
        if (aadharNumber == null || aadharNumber.length() != 12) return false;
        for (int i = 0; i < 12; i++) {
            if (!Character.isDigit(aadharNumber.charAt(i))) return false;
        }
        return true;
    }

    // Validate PAN Number
    public static boolean isValidPanNumber(String panNumber) {
        if (panNumber == null || panNumber.length() != 10) return false;
        // First 5 characters should be letters
        for (int i = 0; i < 5; i++) {
            if (!Character.isLetter(panNumber.charAt(i))) return false;
        }
        // Next 4 characters should be digits
        for (int i = 5; i < 9; i++) {
            if (!Character.isDigit(panNumber.charAt(i))) return false;
        }
        // Last character should be a letter
        return Character.isLetter(panNumber.charAt(9));
    }
}