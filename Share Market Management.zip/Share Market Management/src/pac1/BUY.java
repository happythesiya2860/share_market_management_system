package pac1;
import pac10.*;
import pac6.ShareMarketManagementSystem;
import java.sql.*;
import java.util.Scanner;

public class BUY extends ShareMarketManagementSystem{
    static public String clientMobileNumber = client_mobile_number;
    static public String order;
    public static void call() throws Exception {
        Scanner sc = new Scanner(System.in);
        String dburl = "jdbc:mysql://localhost:3306/share-market";
        String dbuser = "root";
        String dbpass = "";
        String drivername = "com.mysql.cj.jdbc.Driver";
        Class.forName(drivername);
        Connection con = DriverManager.getConnection(dburl, dbuser, dbpass);

        if (con != null) {
            System.out.println("Successful");
        }
        Statement st = con.createStatement();
        String st1 = "CREATE TABLE IF NOT EXISTS PORTFOLIO (STOCK_NAME VARCHAR(50) , STOCK_AVG_PRICE DOUBLE , STOCK_QUANTITY INT," +
                "STOCK_INVEST DOUBLE , CURRENT_VALUE DOUBLE , TOTAL_INVESTMENT DOUBLE , CLIENT_MOBILE_NUMBER VARCHAR(50))";
        st.executeUpdate(st1);

        String print = "SELECT * FROM STOCK_DATA ";
        ResultSet rs9 = st.executeQuery(print);
        while (rs9.next()){
            System.out.println(rs9.getString(1)+"----"+rs9.getDouble(2));
        }
        System.out.println("Enter the stock name:");
        String stock_name = sc.nextLine();

        String st2 = "SELECT * FROM STOCK_DATA WHERE STOCK_NAME = ?";
        PreparedStatement ps1 = con.prepareStatement(st2);
        ps1.setString(1, stock_name);
        ResultSet rs = ps1.executeQuery();
        String sname = "";
        double sprice = 0;
        if (rs.next()) {
            sname = rs.getString("STOCK_NAME");
            sprice = rs.getDouble("STOCK_PRICE");
            sprice  = sprice + sprice * (((Math.random() * (5 - (-5))) + (-5)) / 100);
            System.out.println("Stock: " + sname);
            System.out.println("Price: " + sprice);
        } else {
            System.out.println("Stock not found.");
            return; // Stop further execution
        }
        double sufficient_fund = 0;
        int suggest_quantity = 0;
        int enter_quantity;
        double past_avg_price =0;
        double current_avg_price;
        int past_quantity =0;
        int current_quantity;
        double past_stock_invest = 0;
        double current_stock_invest;
        double past_current_value = 0;
        double current_current_value;
        double past_total_investment = 0;
        double current_total_investment;
        double past_total_value = 0;
        double current_total_value;
        String searchname;
        System.out.println("you want to add stock to buy (yes or no)");
        String ans = sc.nextLine();
        if(ans.equalsIgnoreCase("yes")){

            //recover past data
            String st4 = "SELECT * FROM PORTFOLIO WHERE CLIENT_MOBILE_NUMBER = ? AND STOCK_NAME = ?";
            PreparedStatement ps = con.prepareStatement(st4);
            ps.setString(1, clientMobileNumber);
            ps.setString(2, sname);
            ResultSet rs2 = ps.executeQuery();
            while (rs2.next()){
                past_avg_price = rs2.getDouble(2);
                past_quantity = rs2.getInt(3);
                past_current_value = rs2.getDouble(5);
                past_stock_invest = rs2.getDouble(4);

            }

            String st10 = "SELECT * FROM PORTFOLIO WHERE CLIENT_MOBILE_NUMBER = ?";
            PreparedStatement ps7 = con.prepareStatement(st10);
            ps7.setString(1,clientMobileNumber);
            ResultSet rs6 = ps7.executeQuery();
            while (rs6.next()){
                past_total_investment = rs6.getDouble(6);
                past_total_value = rs6.getDouble(7);
            }

            String st3 = "SELECT FUND FROM FUND WHERE CLIENT_MOBILE_NUMBER = ?";
            PreparedStatement ps6 = con.prepareStatement(st3);
            ps6.setString(1,clientMobileNumber);
            ResultSet rs4 = ps6.executeQuery();
            if(rs4.next()){
                sufficient_fund = rs4.getDouble(1);
                System.out.println("Fund : "+sufficient_fund);
            }
            else {
                System.out.println("Mobile number not found");
            }
            boolean b = false;
            do {
                //suggest qunatity
                suggest_quantity = (int) (sufficient_fund /sprice);
                System.out.println("You should buy quantity : "+suggest_quantity);
                System.out.println("Last quantity : "+past_quantity);
                System.out.println("Enter the quantity : ");
                enter_quantity = sc.nextInt();
                sc.nextLine();
                if(suggest_quantity>=enter_quantity){
                    System.out.println(sname+" "+enter_quantity+" buy success full");
                    current_quantity = past_quantity +enter_quantity;
                    current_stock_invest = enter_quantity*sprice + past_stock_invest;
                    current_total_investment = past_total_investment + enter_quantity*sprice;
                    current_current_value = current_quantity*sprice;
                    current_avg_price = ((enter_quantity*sprice)+(past_avg_price*past_quantity))/(past_quantity+enter_quantity);
                    current_total_value = past_total_value+enter_quantity*sprice;
                    String st6 = "SELECT STOCK_NAME FROM PORTFOLIO WHERE STOCK_NAME = ? AND CLIENT_MOBILE_NUMBER = ?";
                    PreparedStatement ps4 = con.prepareStatement(st6);
                    ps4.setString(1,sname);
                    ps4.setString(2,client_mobile_number);
                    ResultSet rs5 = ps4.executeQuery();
                    if(rs5.next()){
                        searchname = rs5.getString(1);
                    }
                    else {
                        searchname = null;
                    }
                    if(sname.equalsIgnoreCase(searchname)){
                        String st5 = "UPDATE PORTFOLIO SET STOCK_AVG_PRICE =? , STOCK_QUANTITY = ? ," +
                                "STOCK_INVEST = ?, CURRENT_VALUE = ? , TOTAL_INVESTMENT = ?,TOTAL_VALUE = ? WHERE " +
                                "CLIENT_MOBILE_NUMBER = ? AND STOCK_NAME = ?";
                        PreparedStatement ps3 = con.prepareStatement(st5);
                        ps3.setDouble(1, current_avg_price);
                        ps3.setInt(2, current_quantity);
                        ps3.setDouble(3, current_stock_invest);
                        ps3.setDouble(4, current_current_value);
                        ps3.setDouble(5, current_total_investment);
                        ps3.setDouble(6, current_total_value);
                        ps3.setString(7, clientMobileNumber);
                        ps3.setString(8, sname);

                        ps3.executeUpdate();

                        String st9 = "UPDATE PORTFOLIO SET TOTAL_INVESTMENT = ? , TOTAL_VALUE = ? WHERE CLIENT_MOBILE_NUMBER = ?";
                        PreparedStatement ps5 = con.prepareStatement(st9);
                        ps5.setDouble(1,current_total_investment);
                        ps5.setDouble(2,current_total_value);
                        ps5.setString(3,clientMobileNumber);
                        ps5.executeUpdate();
                        order = "BUY "+searchname+"  "+enter_quantity+"";
                        Order.pushorder(order);
                    }
                    else {
                        String st7 = "INSERT INTO PORTFOLIO VALUES(?,?,?,?,?,?,?,?)";
                        PreparedStatement ps8 = con.prepareStatement(st7);
                        ps8.setString(1,sname);
                        ps8.setDouble(2,current_avg_price);
                        ps8.setInt(3,current_quantity);
                        ps8.setDouble(4,current_stock_invest);
                        ps8.setDouble(5,current_current_value);
                        ps8.setDouble(6,current_total_investment);
                        ps8.setDouble(7,current_total_value);
                        ps8.setString(8,clientMobileNumber);
                        ps8.executeUpdate();

                        String st9 = "UPDATE PORTFOLIO SET TOTAL_INVESTMENT = ? , TOTAL_VALUE = ? WHERE CLIENT_MOBILE_NUMBER = ?";
                        PreparedStatement ps5 = con.prepareStatement(st9);
                        ps5.setDouble(1, current_total_investment);
                        ps5.setDouble(2, current_total_value);
                        ps5.setString(3, clientMobileNumber);
                        ps5.executeUpdate();
                        order = "BUY "+searchname+"  "+enter_quantity+"";
                        Order.pushorder(order);
                    }

                    sufficient_fund = sufficient_fund -enter_quantity*sprice;
                    String st8 = "UPDATE FUND SET FUND = ? WHERE CLIENT_MOBILE_NUMBER = ?";
                    PreparedStatement ps9 = con.prepareStatement(st8);
                    ps9.setDouble(1,sufficient_fund);
                    ps9.setString(2,clientMobileNumber);
                    ps9.executeUpdate();
                    b = false;
                }
                else {
                    b = true;
                }
            }while (b);
        }
        updateStockData(sprice,stock_name);
    }
    static public void updateStockData(double newPrice ,String StockName) throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Connect to database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/share-market", "root", "");

        String st1 = "UPDATE STOCK_DATA SET STOCK_PRICE = ? WHERE STOCK_NAME = ?";
        PreparedStatement ps1 = con.prepareStatement(st1);
        ps1.setDouble(1,newPrice);
        ps1.setString(2,StockName);
        ps1.executeUpdate();
    }
}