package pac2;
import pac10.*;
import pac6.ShareMarketManagementSystem;
import java.sql.*;
import java.util.Scanner;

public class SELL extends ShareMarketManagementSystem{
    static String searchname;
    static double sprice = 0;
    static String clientMobileNumber = client_mobile_number;
    static public String order;
    public static void call() throws Exception {
        Scanner sc = new Scanner(System.in);
        String dburl = "jdbc:mysql://localhost:3306/share-market";
        String dbuser = "root";
        String dbpass = "";
        String drivername = "com.mysql.cj.jdbc.Driver";
        Class.forName(drivername);
        Connection con = DriverManager.getConnection(dburl, dbuser, dbpass);

        System.out.println("Enter the stock name to sell : ");
        String sname = sc.nextLine();


        double sufficient_fund = 0;
        int enter_quantity;
        double past_avg_price =0;
        double current_avg_price;
        int past_quantity =0;
        int current_quantity;
        double past_stock_invest = 0;
        double current_stock_invest;
        double past_current_value = 0;
        double current_current_value;
        double past_total_investment = 0;
        double current_total_investment;
        double past_total_value = 0;
        double current_total_value ;

        String st6 = "SELECT * FROM PORTFOLIO WHERE STOCK_NAME = ? AND CLIENT_MOBILE_NUMBER = ?";
        PreparedStatement ps4 = con.prepareStatement(st6);
        ps4.setString(1,sname);
        ps4.setString(2,clientMobileNumber);
        ResultSet rs5 = ps4.executeQuery();
        if(rs5.next()){
            String st2 = "SELECT * FROM STOCK_DATA WHERE STOCK_NAME = ?";
            PreparedStatement ps1 = con.prepareStatement(st2);
            ps1.setString(1, sname);
            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {
                sprice = rs.getDouble("STOCK_PRICE");
                sprice = rs.getDouble("STOCK_PRICE");
                sprice  = sprice + sprice * (((Math.random() * (5 - (-5))) + (-5)) / 100);
            }
            searchname = rs5.getString(1);
            past_quantity = rs5.getInt(3);
            past_avg_price = rs5.getDouble(2);
            past_stock_invest = rs5.getDouble(4);
            past_current_value = rs5.getDouble(5);
            past_total_investment = rs5.getDouble(6);
            past_total_value = rs5.getDouble(7);
            boolean b = false;
            do {
                System.out.println("available quantity : "+past_quantity);
                System.out.println("Enter the quantity to sell");
                enter_quantity = sc.nextInt();
                if(past_quantity>=enter_quantity){
                    b = true;
                }
            }while (!b);
            if(b){
                System.out.println("Sell success full");
                current_quantity = past_quantity - enter_quantity;
                current_avg_price = past_avg_price;
                current_current_value = past_current_value - enter_quantity*sprice;
                current_stock_invest = past_stock_invest - enter_quantity*past_avg_price;
                current_total_investment = past_total_investment - enter_quantity*past_avg_price;
                current_total_value = past_current_value - enter_quantity*sprice;

                String st5 = "UPDATE PORTFOLIO SET STOCK_AVG_PRICE =? , STOCK_QUANTITY = ? ," +
                        "STOCK_INVEST = ?, CURRENT_VALUE = ? , TOTAL_INVESTMENT = ?,TOTAL_VALUE = ? WHERE " +
                        "CLIENT_MOBILE_NUMBER = ? AND STOCK_NAME = ?";
                PreparedStatement ps3 = con.prepareStatement(st5);
                ps3.setDouble(1, current_avg_price);
                ps3.setInt(2, current_quantity);
                ps3.setDouble(3, current_stock_invest);
                ps3.setDouble(4, current_current_value);
                ps3.setDouble(5, current_total_investment);
                ps3.setDouble(6, current_total_value);
                ps3.setString(7, clientMobileNumber);
                ps3.setString(8, sname);

                ps3.executeUpdate();

                String st3 = "SELECT FUND FROM FUND WHERE CLIENT_MOBILE_NUMBER = ?";
                PreparedStatement ps6 = con.prepareStatement(st3);
                ps6.setString(1,clientMobileNumber);
                ResultSet rs4 = ps6.executeQuery();
                if(rs4.next()){
                    sufficient_fund = rs4.getDouble(1);
                }
                sufficient_fund = sufficient_fund +enter_quantity*sprice;
                String st8 = "UPDATE FUND SET FUND = ? WHERE CLIENT_MOBILE_NUMBER = ?";
                PreparedStatement ps9 = con.prepareStatement(st8);
                ps9.setDouble(1,sufficient_fund);
                ps9.setString(2,clientMobileNumber);
                ps9.executeUpdate();
                order = "SELL "+searchname+"  "+enter_quantity+"";
                Order.pushorder(order);
            }
        }
        else {
            System.out.println("Stock not found in portfolio");
        }
        updateStockData(sprice,searchname);
    }
    static public void updateStockData(double newPrice ,String StockName) throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Connect to database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/share-market", "root", "");

        String st1 = "UPDATE STOCK_DATA SET STOCK_PRICE = ? WHERE STOCK_NAME = ?";
        PreparedStatement ps1 = con.prepareStatement(st1);
        ps1.setDouble(1,newPrice);
        ps1.setString(2,StockName);
        ps1.executeUpdate();
    }
}