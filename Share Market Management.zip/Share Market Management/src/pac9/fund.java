package pac9;
import pac11.trancationhistory;
import pac6.ShareMarketManagementSystem;
import java.sql.*;
import java.util.Scanner;

public class fund extends ShareMarketManagementSystem {
    static double fund;
    static double past_fund;
    static public String clientMobileNumber = client_mobile_number;
    public static  void call() throws Exception {
        Scanner sc = new Scanner(System.in);
        // Load JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Connect to database
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/share-market", "root", "");
        Statement st = con.createStatement();
        if (con != null) {
            System.out.println("Successful");
        }


        String st0 = "CREATE  TABLE  IF NOT EXISTS FUND (CLIENT_MOBILE_NUMBER VARCHAR(50) , FUND DOUBLE)";
        st.executeUpdate(st0);

        boolean b = true;
        while (b){
            System.out.println("Enter your choice : \n1.Add fund \n2.Withdraw Fund \n3.View Fund \n4.Exit");
            int choice = sc.nextInt();
            switch (choice){
                case 1 : String st5 = "SELECT * FROM FUND WHERE CLIENT_MOBILE_NUMBER = ?";
                    PreparedStatement ps3 = con.prepareStatement(st5);
                    ps3.setString(1,clientMobileNumber);
                    ResultSet rs2 = ps3.executeQuery();
                    String mobile_number="";
                    String num = clientMobileNumber;
                    while (rs2.next()){
                        mobile_number = rs2.getString(1);
                        past_fund = rs2.getDouble(2);
                    }
                    if(mobile_number.equalsIgnoreCase(clientMobileNumber)){

                        System.out.println("Enter the fund to add");
                        double add_fund = sc.nextDouble();
                        fund = past_fund+add_fund;
                        String st8 = "UPDATE FUND SET FUND = ? WHERE CLIENT_MOBILE_NUMBER = ?";
                        PreparedStatement ps9 = con.prepareStatement(st8);
                        ps9.setDouble(1,fund);
                        ps9.setString(2,clientMobileNumber);
                        ps9.executeUpdate();
                        trancationhistory obj = new trancationhistory("Added",add_fund);
                        trancationhistory.insert(obj);
                    }
                    else {
                        String st3 = "INSERT INTO FUND VALUES(?,0.0)";
                        PreparedStatement ps6 = con.prepareCall(st3);
                        ps6.setString(1,clientMobileNumber);
                        ps6.executeUpdate();
                        System.out.println("Fund :"+fund);
                        System.out.println("Enter fund to add fund");
                        double add_fund = sc.nextDouble();
                        fund = fund+add_fund;
                        System.out.println("Fund : "+fund);
                        String st1 = "UPDATE FUND SET FUND = ? WHERE CLIENT_MOBILE_NUMBER = ?";
                        PreparedStatement ps1 = con.prepareStatement(st1);
                        ps1.setString(2,num);
                        ps1.setDouble(1,fund);
                        ps1.executeUpdate();

                        trancationhistory obj = new trancationhistory("Added",add_fund);
                        trancationhistory.insert(obj);
                    }
                    break;
                case 2 :
                    System.out.println("Enter fund to withdraw fund");
                    double withdraw_fund = sc.nextDouble();
                    if(fund>=withdraw_fund){
                        fund = fund-withdraw_fund;
                        System.out.println("Fund : "+fund);
                        String st2 = "UPDATE FUND SET FUND = ? WHERE CLIENT_MOBILE_NUMBER = ?";
                        PreparedStatement ps2 = con.prepareStatement(st2);
                        ps2.setString(2,clientMobileNumber);
                        ps2.setDouble(1,fund);
                        ps2.executeUpdate();
                        System.out.println("Fund : "+fund);
                        trancationhistory obj = new trancationhistory("Withdraw",withdraw_fund);
                        trancationhistory.insert(obj);
                    }
                    else {
                        System.out.println("Not available sufficient fund");
                    }
                    break;
                case 3 :
                    String st3 = "SELECT * FROM FUND WHERE CLIENT_MOBILE_NUMBER = ?";
                    PreparedStatement ps4 = con.prepareStatement(st3);
                    ps4.setString(1,clientMobileNumber);
                    ResultSet rs1 = ps4.executeQuery();
                    double current_fund;
                    while (rs1.next()){
                        current_fund = rs1.getDouble(2);
                        System.out.println("Fund : "+current_fund);
                    }
                    break;
                case 4 : b = false;
                    break;
            }
        }
    }
}