package pac11;
public class trancationhistory {
    public  String type ;
    public  double fund;
    public trancationhistory(String type , double fund){
        this.type = type;
        this.fund = fund;
    }
    static class Node {
        trancationhistory data;
        Node next;
        Node(trancationhistory data){
            this.data = data;
            next = null;
        }
    }
    static Node head = null;
    public static void insert(trancationhistory data){
        Node n1 = new Node(data);
        Node temp = head;
        if(head == null){
            head = n1;
        }
        else {
            while (temp.next!=null){
                temp = temp.next;
            }
            temp.next = n1;
        }
    }
    public static void display(){
        Node temp = head;
        while (temp!=null){
            trancationhistory obj = temp.data;
            System.out.println(obj.fund+" "+obj.type);
            temp = temp.next;
        }
    }
}